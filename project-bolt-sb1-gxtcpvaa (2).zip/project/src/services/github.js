const { verifySelector } = require('../utils/selectorChecker');

async function loginGitHub(page, credentials) {
  try {
    await page.goto('https://github.com/login');
    
    const usernameSelector = await verifySelector(page, '#login_field');
    const passwordSelector = await verifySelector(page, '#password');
    const submitSelector = await verifySelector(page, 'input[type="submit"]');
    
    await page.type(usernameSelector, credentials.username);
    await page.type(passwordSelector, credentials.password);
    
    // Add delay before submitting to ensure password is typed completely
    await page.waitForTimeout(1000);
    await page.click(submitSelector);
    
    await page.waitForNavigation();
  } catch (error) {
    console.error('GitHub login failed:', error.message);
    throw error;
  }
}

module.exports = { loginGitHub };