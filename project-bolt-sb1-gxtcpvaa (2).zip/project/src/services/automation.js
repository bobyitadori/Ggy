const { startRecording, stopRecording } = require('../utils/recorder');
const { TelegramService } = require('./telegram');

async function runAutomation(browser, config, steps) {
  const telegram = new TelegramService(config);
  let page = null;
  let recording = null;
  
  try {
    page = await browser.newPage();
    recording = await startRecording(page);
    
    for (const step of steps) {
      await step(page);
      const screenshot = await page.screenshot({ fullPage: true });
      await telegram.sendScreenshot(screenshot);
      
      console.log('Waiting for confirmation before continuing...');
      const shouldContinue = await telegram.waitForConfirmation();
      
      if (!shouldContinue) {
        console.log('Retrying current step...');
        await step(page);
      }
    }
    
    await stopRecording(page);
    await telegram.sendVideo('recording.webm');
    
  } catch (error) {
    console.error('Automation failed:', error.message);
    throw error;
  }
}

module.exports = { runAutomation };