const { verifySelector } = require('../utils/selectorChecker');

async function loginCS50Dev(page) {
  try {
    await page.goto('https://cs50.dev');
    
    const githubButtonSelector = await verifySelector(page, '.github-login-button');
    await page.waitForSelector(githubButtonSelector);
    await page.click(githubButtonSelector);
    
    const nodejsSelector = await verifySelector(page, '.nodejs-option');
    await page.waitForSelector(nodejsSelector);
    await page.click(nodejsSelector);
  } catch (error) {
    console.error('CS50 login failed:', error.message);
    throw error;
  }
}

module.exports = { loginCS50Dev };