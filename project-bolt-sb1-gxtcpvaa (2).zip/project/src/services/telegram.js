const TelegramBot = require('node-telegram-bot-api');
const fs = require('fs');

class TelegramService {
  constructor(config) {
    this.bot = new TelegramBot(config.telegram.botToken, { polling: true });
    this.chatId = config.telegram.chatId;
  }

  async sendScreenshot(screenshot) {
    try {
      await this.bot.sendPhoto(this.chatId, screenshot, {
        caption: 'Step completed. Reply Y to continue, N to retry'
      });
    } catch (error) {
      console.error('Failed to send Telegram screenshot:', error.message);
      throw error;
    }
  }

  async sendVideo(videoPath) {
    try {
      if (fs.existsSync(videoPath)) {
        await this.bot.sendVideo(this.chatId, videoPath, {
          caption: 'Automation Recording'
        });
      }
    } catch (error) {
      console.error('Failed to send Telegram video:', error.message);
      throw error;
    }
  }

  async waitForConfirmation() {
    return new Promise((resolve) => {
      console.log('Waiting for confirmation (Y/N) on Telegram...');
      
      const messageHandler = (msg) => {
        if (msg.chat.id.toString() === this.chatId.toString()) {
          const response = msg.text.toUpperCase();
          if (response === 'Y' || response === 'N') {
            this.bot.removeListener('message', messageHandler);
            resolve(response === 'Y');
          }
        }
      };
      
      this.bot.on('message', messageHandler);
    });
  }
}

module.exports = { TelegramService };