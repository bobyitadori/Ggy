const path = require('path');

async function startRecording(page) {
  await page.screencast({
    path: path.join(process.cwd(), 'recording.webm'),
    fps: 30
  });
}

async function stopRecording(page) {
  await page.stopScreencast();
}

module.exports = { startRecording, stopRecording };