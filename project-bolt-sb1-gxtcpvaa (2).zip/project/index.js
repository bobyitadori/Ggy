const puppeteer = require('puppeteer');
const config = require('./src/config');
const { loginGitHub } = require('./src/services/github');
const { loginCS50Dev } = require('./src/services/cs50');
const { runAutomation } = require('./src/services/automation');

async function main() {
  let browser;
  
  try {
    browser = await puppeteer.launch({ 
      headless: "new",
      args: ['--no-sandbox']
    });

    const steps = [
      async (page) => await loginGitHub(page, config.github),
      async (page) => await loginCS50Dev(page)
    ];

    await runAutomation(browser, config, steps);
    
  } catch (error) {
    console.error('Application error:', error.message);
  } finally {
    if (browser) {
      await browser.close();
    }
  }
}

if (require.main === module) {
  main();
}

module.exports = { main };